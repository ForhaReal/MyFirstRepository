# Diskette

![Klobig](oredict:oc:floppy)

Die Diskette ist das günstigste und kleinste Speichermedium in OpenComputers. Es ist ein nützliches Item für das frühe Spiel um Daten zwischen den Geräten zu transferieren. Disketten mit nützlichen Programmen können in Dungeons gefunden werden (wie der OpenPrograms Package Manager, womit Programme von einem zentralen Github-Repository installiert werden können.)
