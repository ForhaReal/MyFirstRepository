# Leistungswandler

![Einer von uns? Einer von uns!](oredict:oc:powerConverter)

Der Leistungswandler stellt den schnellsten Weg dar, um Energie von anderen Mods zu OpenComputers eigenem Energiesystem zu konvertieren. Wenn nur ein Computer verwendet wird, wird dieser nicht nötig sein. Bei einer großen Kondensatorbank, die nur dann und wann geleert wird, ist er ebenfalls nicht nötig. Wenn hingegen eine [Elektronik-Werkbank](assembler.md) oder eine [Ladestation](charger.md) direkt mit Energie versorgt werden soll, ist es eine gute Idee, diesen Konverter zu verwenden, anstatt sie direkt zu einer externen Energiequelle anzuschließen.
