# Schneidedraht

![Kein Würgedraht. Wirklich.](oredict:oc:materialCuttingWire)

Dieses Item wird nur im Hard-Mode-Rezept für [Leiterplattenrohlinge](rawCircuitBoard.md) verwendet. Ineffektiv.
