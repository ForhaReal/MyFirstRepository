# Netzwerkkarte

![Tritt ins Netzwerk ein.](oredict:oc:lanCard)

Die Netzwerkkarte erlaubt es [Computern](../general/computer.md), Nachrichten vom Netzwerk zu empfangen und zum Netzwerk zu senden. Nachrichten (oder Pakete) können über das ganze Netzwerk oder zu spezifischen Knotenpunkten mit einer bestimmten Adresse gesendet werden. [Switche](../block/switch.md) und [Access Points](../block/accessPoint.md) können verwendet werden, um verschiedene Netzwerke miteinander zu verbinden. Nachrichten können dann zwischen verschiedenen Netzwerken hin- und hergesendet werden, auch zwischen unterschiedlichen Subnetzwerken. 
