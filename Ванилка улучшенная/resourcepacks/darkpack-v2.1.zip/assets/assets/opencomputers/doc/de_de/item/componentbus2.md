#REDIRECT componentBus1.md
