# Engels-Upgrade

![Hallelujah.](oredict:oc:angelUpgrade)

Dieses Upgrade ermöglicht es [Robotern](../block/robot.md) Blöcke mitten in die Luft zu platzieren.
