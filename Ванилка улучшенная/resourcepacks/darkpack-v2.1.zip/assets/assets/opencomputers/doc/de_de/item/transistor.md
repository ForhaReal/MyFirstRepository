# Transistor

![Ich denke ich habe alle meine Referenzen aufgebraucht.](oredict:oc:materialTransistor)

Der Transistor ist einer der grundlegendsten Crafting-Materialien in OpenComputers. Es wird hauptsächlich für [Microchips](chip1.md) und andere elektronische Kleinigkeiten verwendet.
