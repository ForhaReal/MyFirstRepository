# Leinen-Upgrade

![-Angeleint- ~ Vexatos 2015](oredict:oc:leashUpgrade)

Das Leinen-Upgrade ermöglicht es, Leinen auf Tiere anzulegen. Das entsprechende Gerät (zum Beispiel eine [Drohne](drone.md)) kann dann Tiere führen, auch mehrere auf einmal.  Es ist damit recht einfach Herden zu bewegen. 
