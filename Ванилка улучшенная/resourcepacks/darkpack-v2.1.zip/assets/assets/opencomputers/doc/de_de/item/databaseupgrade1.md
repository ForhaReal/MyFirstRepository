# Datenbank-Upgrade

![Living in the database.](oredict:oc:databaseUpgrade1)

Das Datenbank-Upgrade kann konfiguriert werden um eine Liste von Itemstack-Repräsentationen zu speichern. Die können von anderen Komponenten verwendet werden. Das ist besonders nützlich für Items die mit ihren NBT-Daten sortiert werden. 

Um eine Datenbank zu konfigurieren klick es rechts mit der Datenbank in der Hand ab. Platziere die Stacks die du konfigurieren möchtest im Inventar. Es wird ein "Geisterstack" gespeichert, kein echtes Item.

Alternativ kann die Datenbank mit der Komponenten-API des [Inventarbedienungs-Upgrades](inventoryControllerUpgrade.md) und des [Geolyzers](../block/geolyzer.md) verändert werden.
