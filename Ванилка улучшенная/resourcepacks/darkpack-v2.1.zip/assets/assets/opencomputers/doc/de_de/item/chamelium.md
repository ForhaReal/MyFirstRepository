# Chamälium

![Kommt vom Wort "Chamäleon".](oredict:oc:chamelium)

Chamälium ist ein formbares Material das für [3D-Drucke](../block/print.md) in [3D-Druckern](../block/printer.md) verwendet wird. Sonst ist es nutzlos und damit sehr nützlich um monochrome Bereiche zu erstellen.

Es kann zudem zu einem [Chamäliumblock](../block/chameliumBlock.md) kombiniert werden.

Wie der Tooltip sagt kann es Nebenwirkungen haben, also sollte es mit Vorsicht genossen werden. Oder noch besser: gar nicht.
