# Convertisseur énergétique

![L'un des nôtres ? L'un des nôtres !](oredict:oc:powerConverter)

Le convertisseur énergétique est la manière la plus rapide de convertir de l'énergie provenant d'autres mods en énergie interne à OpenComputers. Si vous utilisez un seul ordinateur, vous n'aurez probablement pas besoin de convertisseur. Si vous avez un grand groupe de capaciteurs dont vous utilisez l'énergie de temps en temps, vous n'en aurez sûrement pas besoin non plus. Cependant, si vous souhaitez alimenter directement un [assembleur électronique](assembler.md) ou un [chargeur](charger.md), c'est généralement une bonne idée d'utiliser un convertiseeur au lieu de les connecter directement à une source externe d'énergie.
