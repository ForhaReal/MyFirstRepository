# Bloc de Chamélium

![Tellement... blanc.](oredict:oc:chameliumBlock)

Quelques morceaux de [chamélium](../item/chamelium.md) peuvent être combinés pour fournir un bloc monochrome à des fins décoratives. Les blocs de chamélium peuvent aussi être teintés avec n'importe laquelle des 16 couleurs de Minecraft.

Utiliser un bloc de chamélium comme texture pour les [impressions 3D](print.md) fournit une surface propre et blanche pour appliquer les teintes.
