# Headline with more lines  [with link](redirect1.md) and *some* more

This is some test text for the subset of Markdown supported by the planned ingame documentation system for OpenComputers.
![This is a tooltip...](opencomputers:textures/gui/printer_ink.png)
![This is a tooltip...](opencomputers:/textures/gui/printer_material.png)
*This* is *italic* text, ~~strikethrough~~ maybe abc-ter **some** text **in bold**. Is _this underlined_? Oh, no, _it's also italic!_ Well, this [a link](../index.md).
![This is rendered live.](oredict:oc:assembler)
## Smaller headline [also with *link* but this __one__ longer](../block/adapter.md)

![This is another tooltip.](item:OpenComputers:item@23)

some text directly above the item stack renderer to test spacing
![All the colors.](oredict:craftingPiston)
some text directly below the item stack renderer to test spacing

This is *italic
over two* lines. But *this ... no *this is* **_bold italic_** *text*.

### even smaller

*not italic *because ** why would it be*eh

`test for code`
`that's not code yet`
`function f(a)`
`  testingIndent(a)`
`  do`
`    lalala()`
`  end`
`end`
yeah, line spacing is a bit low, but otherwise too little text fits on one screen.
this is some `code` that's inline. then `some more CODE that` line wraps and so on.

isn't*.

   # not a header

* this is a list item and the text that will be wrapped will be indented appropriately
- this should also `work for code rendered text, if it doesn't i` will be a sad person

asdasd ![oh my god, the recursion!](img/example.png) qweqwe

And finally, [this is a link!](https://avatars1.githubusercontent.com/u/514903).

![broken item image](item:this is broken)
![broken item image](block:this is broken)
![broken item image](oredict:this is broken)

wrap testing
12345678901234567890.1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
`123456789012345678901234567890.12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890`

* 12345678901234567890.1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
- `123456789012345678901234567890.12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890`

this is a test for an![](oredict:oc:cpu1)an inline image kakakakalalsd 123 as

this is a test for an![](oredict:oc:cpu1)
an image with a break after it

this is a test for an
![](oredict:oc:cpu1)
an image between two lines

this is a test for an

![](oredict:oc:cpu1)

an image between two blank lines
