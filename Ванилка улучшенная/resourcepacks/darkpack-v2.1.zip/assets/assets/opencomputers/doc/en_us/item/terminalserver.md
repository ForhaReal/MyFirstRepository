# Terminal Server

![Remote Viewing](oredict:oc:terminalServer)

Terminal servers provides a virtual [screen](../block/screen1.md) and [keyboard](../block/keyboard.md) which can be controlled via [remote terminals](terminal.md). See the [remote terminal](terminal.md) manual entry for more information. Terminal servers must be installed in a [rack](../block/rack.md) to function.
