# Angel Upgrade

![Hallelujah.](oredict:oc:angelUpgrade)

This upgrade allows [robots](../block/robot.md) to place blocks in thin air, without a reference block.