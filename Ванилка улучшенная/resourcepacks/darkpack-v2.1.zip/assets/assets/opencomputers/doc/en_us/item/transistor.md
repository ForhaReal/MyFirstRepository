# Transistor

![I think I've used up all my references.](oredict:oc:materialTransistor)

The transistor is one of the most basic crafting ingredients in OpenComputers. It is mainly used to craft [microchips](chip1.md) and other electronic goodies.
