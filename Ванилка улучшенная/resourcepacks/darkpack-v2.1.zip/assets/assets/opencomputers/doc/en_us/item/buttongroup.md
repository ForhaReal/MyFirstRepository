# Button Group

![Needs more buttons.](oredict:oc:materialButtonGroup)

Because you *always* have too many buttons lying around somewhere. Don't lie. We all shift-click that button recipe time and again. Button groups are used to build [keyboards](../block/keyboard.md). 
