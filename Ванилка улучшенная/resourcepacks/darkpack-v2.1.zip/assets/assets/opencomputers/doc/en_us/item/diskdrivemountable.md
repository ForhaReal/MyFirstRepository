# Mountable Disk Drive

![Snuggly](oredict:oc:diskDriveMountable)

This device is functionally equivalent to a regular [disk drive](../block/diskDrive.md), except that it is installed in a [rack](../block/rack.md).
