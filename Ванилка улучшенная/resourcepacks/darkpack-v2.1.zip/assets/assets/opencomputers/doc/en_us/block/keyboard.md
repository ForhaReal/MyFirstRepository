# Keyboard

![QWERTY](oredict:oc:keyboard)

A keyboard is needed to type text on [screens](screen1.md), be they in the world or built into devices such as [robots](robot.md) or [tablets](../item/tablet.md).

For a keyboard to work with a [screen](screen1.md) in the world, it has to be placed next to the [screen](screen1.md), facing that [screen](screen1.md), or placed directly on the [screen](screen1.md) (on top or on one of its sides). You can tell that a keyboard is "connected" to a [screen](screen1.md) if the [screen's](screen1.md) GUI opens up when using the keyboard.