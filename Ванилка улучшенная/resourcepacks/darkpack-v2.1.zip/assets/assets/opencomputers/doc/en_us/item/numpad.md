# Numeric Keypad

![Check for fingerprints.](oredict:oc:materialNumPad)

The Numeric keypad is part of every [keyboard](../block/keyboard.md). It allows you to enter numbers. 